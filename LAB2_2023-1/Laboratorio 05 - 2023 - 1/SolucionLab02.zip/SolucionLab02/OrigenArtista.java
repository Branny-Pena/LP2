enum OrigenArtista{
	NACIONAL, INTERNACIONAL
}